/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ekloufinal;

/**
 *
 * @author EklouFinal
 */
public class InfoModel {
    
    //Field
     private double size;
     private double sandwich;
     private double drink;
     private double calculate;
     
   // Setter and Getter

    /**
     *
     * @return
     */

    public double getSize() {
        return size;
    }

    /**
     *
     * @param size
     */
    public void setSize(double size) {
        this.size = size;
    }

    /**
     *
     * @return
     */
    public double getSandwich() {
        return sandwich;
    }

    /**
     *
     * @param sandwich
     */
    public void setSandwich(double sandwich) {
        this.sandwich = sandwich;
    }

    /**
     *
     * @return
     */
    public double getDrink() {
        return drink;
    }

    /**
     *
     * @param drink
     */
    public void setDrink(double drink) {
        this.drink = drink;
    }

    /**
     *
     * @return
     */
    public double getCalculate() {
        return calculate;
    }

    /**
     *
     * @param calculate
     */
    public void setCalculate(double calculate) {
        this.calculate = calculate;
    }
         private double calculate(){
     double calculate = size + sandwich + drink;
     return calculate;
    }

   // void setVisible(boolean b) {
      //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    //}
    
}

