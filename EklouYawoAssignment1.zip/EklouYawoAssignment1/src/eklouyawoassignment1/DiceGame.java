/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eklouyawoassignment1;

import java.util.Random;
import java.util.Scanner;
/**
 *
 * @author National Pawn
 */
public class DiceGame {
//Fields
    private Player [] players;
    private int numPlayers;
    private int pot;
    private boolean gameOver;  
    int gameMode;
    Scanner keyboard = new Scanner(System.in);

    /**
     *Constructor
     */
    public DiceGame(){
        setUpGame();
    }
    
    /**
     *
     * @return numPlayers
     */
    public int getNumPlayers(){
    return numPlayers;
    }
    
    /**
     *
     * @return players
     */
    public Player[] getPlayers(){
        
    return players;
    }
    
    /**
     * 
     * @return gameOver
     */
    public boolean isGameOver(){
         
    return gameOver;
    }
    
    /**
     *The setUpGame method set up the information to start the game
     */
    public void setUpGame(){
       System.out.println("Enter 1 for easy mode game "+"\n"+
                  "Enter 2 for difficult mode game");
        gameMode = keyboard.nextInt();
       while(gameMode != 1 && gameMode!= 2 ){
          System.out.println("Wrong entry!"+"\n"+ "Enter 1 for easy mode"+ "\n"+ 
                  "Enter 2 for difficult mode"); 
          gameMode = keyboard.nextInt();
       }
       System.out.println("Number of Players: ");
       numPlayers = keyboard.nextInt();
       players = new Player[numPlayers];
       for(int i = 0; i< players.length; i++){
         System.out.println("Enter name of player " + i +": ");
         Scanner keyboard = new Scanner(System.in);
          String name = keyboard.nextLine();
          players[i] = new Player(name);
     }
         displayRules();
    
    }

    /**
     *displayRules method prints out the rules for the game
     */
    public void displayRules(){
      if(gameMode == 1)
        System.out.println("RULES: Each player places a bet and chooses a number between 2 and 12."+ "\n"+ 
             "The total of all the bets forms a 'pot'"+"\n"+ 
             "Then two dice are rolled."+"\n"+
             "If one of the player's bet is correct, they win the entire pot."+"\n"+
             "If more than one players' bets are correct, the one who bet the most wins"+"\n"+
             "the entire pot."+"\n"+
             "If there is a tie, they split the pot."+"\n"+
             "The game is over if one of the players runs out of money.");
        else
         System.out.println("RULES: Each player places a bet and chooses"+
             " two numbers between 1 and 6."+ "\n"+ 
             "The total of all the bets forms a 'pot'"+"\n"+ 
             "Then two dice are rolled."+"\n"+
             "If one of the player's bet is correct, they win the entire pot."+"\n"+
             "If more than one players' bets are correct, the one who bet the most wins"+"\n"+
             "the entire pot."+"\n"+
             "If there is a tie, they split the pot."+"\n"+
             "The game is over if one of the players runs out of money.");
    }
    
    /**
     *playGame method allows the players to play the game
     */
    public void playGame(){
        int outcome = 0;
        int outcome1 = 0;
        int outcome2 = 0;
    for(Player player:players){
        playTurn(player); 
        pot += player.getBetAmount();
    }
      System.out.println("The balance in the pot is: $" + pot);
       Random r = new Random();
        int n1 = 1 + r.nextInt(6);
        int n2 =1 + r.nextInt(6);
        if(gameMode == 1){
         outcome = n1 + n2;
         checkWinner(outcome);
         System.out.println("The right guess is: " + outcome);
        }
        else
        {
          outcome1 = n1;
          outcome2 = n2;
          checkWinner(outcome1, outcome2);
          System.out.println("The right guesses in order are: " + outcome1+", "+ outcome2);
        }
        
        
     for(Player player: players)
         if(player.getBalance() == 0)
             gameOver = true;
         
    }
    
    /**
     * playTurn method allows each player to bet an amount
     * and guess 
     * @param player
     */
    public void playTurn(Player player){
     System.out.println(player.getName() +","+"\n" + "Your current balance is: $"+ 
                       player.getBalance());
     int betAmount = 0;
     System.out.println("Enter the amount of your bet: ");
     betAmount = keyboard.nextInt();
     while(betAmount > player.getBalance()){
        System.out.println("Bet balance exceeds available funds");
        System.out.println("Enter the amount of the bet: ");
        betAmount = keyboard.nextInt();
     }
      player.setBetAmount(betAmount);
    int balance = player.getBalance();
        balance -= betAmount;
        player.setBalance(balance);
    if(gameMode == 1){
    System.out.println("Enter your guess: ");
    int guess = keyboard.nextInt();
    while(guess < 2 || guess> 12){
        System.out.println("Invalid! Enter a guess in the range of 2 and 12.");
        guess = keyboard.nextInt();
     }
    }
    else
    {
     System.out.println("Enter your first guess: ");
     int firstGuess = keyboard.nextInt();
     while(firstGuess < 1 || firstGuess> 6){
        System.out.println("Invalid! Enter a guess in the range of 1 and 6.");
        firstGuess = keyboard.nextInt();
            }
     System.out.println("Enter your Second guess: ");
     int secondGuess = keyboard.nextInt();
     while(secondGuess < 1 || secondGuess>6){
        System.out.println("Invalid! Enter a guess in the range of 1 and 6.");
        secondGuess = keyboard.nextInt();
            }     
       }
     

    }
    
    /**
     *checkWinner method allows to find out if players guessed the outcome
     * and update each player's balance and the balance of the pot accordingly
     * @param outcome
     */
    public void checkWinner(int outcome){
        
     for(Player player: players){
         int balance = 500;
        if(player.getGuess()!= outcome) {
              
             balance -= player.getBetAmount();
             
             System.out.println(player.getName() +", your balance is: $" + balance);
        
            pot = player.getBetAmount();
            player.setBalance(balance);
           //System.out.println("The balance in the pot is: "+ pot);
        }
         else if(player.getGuess() == outcome && 
                 player.getBetAmount()> player.getBetAmount()){
         
             balance += player.getBetAmount();
             System.out.println(player.getName() +", your balance is: $" + balance);
             pot = 0;
             player.setBalance(balance);
        }else{
             balance = player.getBalance(); 
             balance += pot;
             System.out.println(player.getName() +", your balance is: $" + balance);
             pot = 0;
             player.setBalance(balance);
        }
       }
    
    }
    
    /**
     *checkWinner method overload the first checkWinner method
     * it allows to find out if players guessed the two outcomes
     * and update each player's balance and the balance of the pot accordingly
     * @param outcome1
     * @param outcome2
     */
    public void checkWinner(int outcome1, int outcome2){
       
     for(Player player: players){
         int balance = 500;
        if(player.getFirstGuess()!= outcome1 && player.getSecondGuess()!= outcome2) {
             
             balance -= player.getBetAmount();
             System.out.println(player.getName() +", your balance is: $" + balance);
             
            pot += player.getBetAmount();
            player.setBalance(balance);
          
        }else if(player.getFirstGuess() == outcome1 && player.getSecondGuess() == outcome2 &&
             player.getBetAmount()> player.getBetAmount()){
             balance = player.getBalance();
             balance += player.getBalance();
             pot = 0;
             player.setBalance(balance);
        }else{
             balance = player.getBalance(); 
             balance += pot;
             pot = 0;
             player.setBalance(balance);
        } 
           
       }
    }
}
