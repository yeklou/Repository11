/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eklouyawoassignment1;

/**
 *
 * @author National Pawn
 */
public class Player {
  //Fields
    private String name;
    private int balance;
    private int betAmount;
    private int guess;
    int INITIAL_BALANCE;
    private int firstGuess;
    private int secondGuess;

    /**
     * Constructor
     * @param nameP
     */
    public Player(String nameP){
        name = nameP;
        balance = INITIAL_BALANCE = 500;
    }

    /**
     * getName method allows to get the name of a player
     * @return name
     */
    public String getName(){
     return name;
    }
    
    /**
     * getBalance method allows to get the balance of a player
     * @return balance
     */
    public int getBalance(){
     return balance;
    }
     
    /**
     * getBetAmount method allows to get the amount of a player's bet 
     * @return betAmount
     */
    public int getBetAmount(){
     return betAmount;
    }
     
    /**
     * getGuess method allows to get a player's guess
     * @return guess
     */
    public int getGuess(){
     return guess;
    }
    
    /**
     * setBalance method sets the balance of a player
     * @param balanceP
     */
    public void setBalance(int balanceP){
     balance = balanceP;
    }
     
    /**
     * setBetAmount sets the bet amount for players
     * @param amount
     */
    public void setBetAmount(int amount){
     betAmount = amount;
    }
     
    /**
     * setGuess method sets the guess of players
     * @param guessP
     */
    public void setGuess(int guessP){
     guess = guessP;
    }

    /**
     * getFirstGuess method allows to get the first guess of a player
     * @return firstGuess
     */
    public int getFirstGuess() {
        return firstGuess;
    }

    /**
     * getSecondGuess method allows to get the second guess of players
     * @return secondGuess
     */
    public int getSecondGuess() {
        return secondGuess;
    }

    /**
     * setFirstGuess method sets the first guess of players
     * @param firstGuess
     */
    public void setFirstGuess(int firstGuess) {
        this.firstGuess = firstGuess;
    }

    /**
     * setSecondGuess method sets the second guess of players
     * @param secondGuess
     */
    public void setSecondGuess(int secondGuess) {
        this.secondGuess = secondGuess;
    }
    
}
