/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package stringtest;

import java.util.Scanner;

/**
 *
 * @author clatulip, modified by nblong
 */
public class StringTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
       
        while (true) {
            System.out.println("Please enter a string of text:");
            String s = sc.nextLine();
            System.out.println("String is: " + s);
            System.out.println("Please enter a number between 0 and 6:");

            
            boolean hasNumber = false;
            int i = 0;
            while (hasNumber == false ){
                if (sc.hasNext()) {
                    try {
                        i = sc.nextInt();
                        hasNumber = true;
                        sc.nextLine();
                    } catch (Exception e) {
                        System.out.println("You must enter a number from 0-6. Please try an again.");
                    }
                }
            }
            System.out.println("You entered: " + i);
            
            switch (i) {
                case 0:
                    // TODO: determine whether there is a space in this string
                    if(s.contains(" "))
                    // if so, replace the first space with the word 'SPACE', print out string
                        System.out.println(s.replaceFirst(" ", "SPACE"));
                        
                    break;
                case 1:
                    // TODO: count and print the number of spaces in this string
                    int count =0;
                   for(i = 0; i<s.length();++i)
                    if(s.charAt(i)==' ')
                        count +=count;
                      System.out.println("Number of spaces: "+ count);
                    break;
                case 2:
                    //TODO: remove all the spaces in the string
                   // if(s.contains(" "))
                        s = s.replaceAll(" ", "");
                    //print out result
                        System.out.println(s);
                    break;
                case 3:
                    // TODO: make sure there is at least one number in the string,
                   //
                    for(i =0; i< s.length();++i)
                     if(s.matches(".*\\d.*"))
                       System.out.println("The text contains at least one number");
                    // if there isn't, report an error, otherwise do nothing
                     else
                       System.out.println("There is an error. The text contains no number");
                    break;
                case 4:
                    // TODO: concatenate this string with itself, print out result
                    System.out.println(s.concat(s));
                    break;
                case 5:
                    // TODO: make every second letter uppercase, leave non-letter characters alone
                    for(i =0; i< s.length(); ++i)
                        if(i%2 != 0)
                            s = s.toUpperCase();
                    // print out result
                       System.out.println(s);
                    break;
                case 6:
                    return;
            }
        
        }     
            
        
    }
    
}
