
import java.util.Arrays;

/**
 * ArrayCircularQueue which implement QueueADT
 * Use an array as the stack container, and use the
 * variable size to represent the total number of elements in the queue. 
 * In the array, new data element will always be stored in the end of queue, 
 * which is represented in the index of (front + size) % array length.
 * 
 * @author ITSC 2214
 *
 * @version 1.0
 */

/** An array-based StackADT. */
public class ArrayStack<E> implements StackADT<E> {

  /** Array of items in this StackADT. */
  private E[] data;
  private int DEFAULT__CAPACITY;

  /** Number of items currently in this StackADT. */
  private int top;

  /** The StackADT is initialized to be empty. */
  public ArrayStack() {
    //TODO Instantiate the array-based data collection
     //this(DEFAULT_CAPACITY);
     this.data = null;
     this.top = 0;
  }

  @Override
  public boolean isEmpty() {
      //TODO Evaluate whether the stack is empty
               if (top <= 0)
             return true;
        else
             return false;
  }

  /** Return true if data is full. */
  protected boolean isFull() {
      //TODO Evaluate whether the queue is full
       return top == data.length-1;

  }

  @Override
  public E peek() throws EmptyCollectionException{
      //TODO Retrieve element at the end of the stack (index of the data array: top -1) 
      //Do not modify the Stack.
            if (isEmpty())
            throw new EmptyCollectionException("stack");

        //TODO return the element at the index of top -1
        return data[top-1];

  }

  @Override
  public E pop() throws EmptyCollectionException {
      //TODO Remove and return the top item on the stack (data array)
            if (isEmpty())
            throw new EmptyCollectionException("stack");

        //TODO change top, removed element from the top of stack, change, and reset element to null in the current top, and return the element being removed
        top--;
        E result = data[top];
        data[top] = null; 

        return result;

  }

  @Override
  public void push(E target) {
    //TODO Add targer to the top of the stack (data array)
            if (size() == data.length) 
            data = Arrays.copyOf(data, data.length * 2);  

        //TODO reset element in the top of stack to be the given element and change the top
        data[top] = target;
        top++;
    }

  

  /** Double the length of data. */
  protected void expandCapacity() {
    E[] newData = (E[])(new Object[data.length * 2]); // Warning
    for (int i = 0; i < data.length; i++) {
      newData[i] = data[i];
    }
    data = newData;
  }

    @Override
    public int size() {
        //TODO return the size of the stack, identified by the variable top
        return top;

    }
}
