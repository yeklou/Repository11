/**
 * Linked list implementation of Stacks. 
 * 
 * @author ITSC 2214
 *
 * @version 1.0
 */

public class LinkedStack <T> implements StackADT<T>{
    SinglyLinkedNode<T> top;
    int size;
    
    public LinkedStack(){
        //TODO Instantiate the linked list-based data collection
         this.top = null;
         this.size = 0;

    }

    @Override
    public boolean isEmpty() {
        //TODO Evaluate whether the stack is empty
        return (size == 0);

    }

    //@Override
   // @Override
    public T peek() throws EmptyCollectionException {
        //TODO Return the top item on this stack, but do not modify the stack.
        //Corresponding to return the element in the node referred by the reference top
       if (isEmpty())
           throw new EmptyCollectionException("stack"); 

        return top.getElement();

    }

    @Override
    public T pop()  throws EmptyCollectionException{
        //TODO Remove and return the top item on the stack
        //Corresponding to retrieve the top node and reset the top reference to the reference of its next node
        if (isEmpty())
           throw new EmptyCollectionException("stack");

        T result = top.getElement();
        top = top.getNext();
        size--;
 
        return result;

    }

    @Override
    public void push(T target) {
        //TODO Add targer to the top of the stack (represented by the top reference node)
     SinglyLinkedNode<T> temp = new SinglyLinkedNode<T>(target);

        temp.setNext(top);
        top = temp;
        size++;

    }

    @Override
    public int size() {
        //TODO return the size of the stack 
        return size;

    }


}
