/**
 * Interface of Queues. 
 * 
 * @author ITSC 2214
 *
 * @version 1.0
 */

/** A first-in, first-out queue of Objects.
 * @param <E> */
public interface QueueADT<E> {

  /** Add target to the back of this QueueADT.
     * @param target */
  public void enqueue(E target);

  /** Return true if this QueueADT is empty.
     * @return  */
  public boolean isEmpty();

  /**
   * Remove and return the front item from this QueueADT.
     * @return 
     * @throws EmptyCollectionException
   * @throws EmptyStructureException if the QueueADT is empty.
   */
  public E dequeue() throws EmptyCollectionException;
  
      /**
     * Returns (without removing) the element that is in the head of the queue
     * @return the element in the head of the queue
     * @throws EmptyCollectionException 
     */
    public E first() throws EmptyCollectionException;

    /** Number of elements of this StackADT.
     * @return  */
    public int size();
}
